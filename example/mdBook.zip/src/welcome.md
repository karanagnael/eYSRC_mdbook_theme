<style>
.back{
	position: fixed;
	width: 250px;
	height: 250px;
	top: 50%;
	left: 50%;
    margin-top: auto;
    margin-left: auto;
	opacity: 0.15;
    z-index: -1;
	}
</style>

<center>
    <h1>Welcome to Sustain Theme!</h1>
</center>

---

<br/>

<center><img src="https://raw.githubusercontent.com/hari-vickey/mdbook-assets/master/art/eb_theme.png" /></center>

new theme :)

<center><b>ALL THE BEST! Happy Learning !!</b></center>

<br /><center><img src="https://raw.githubusercontent.com/hari-vickey/mdbook-assets/main/art/innovate_problem_solution.png" /></center>

